# ML Prediction Playground

This is an interactive playground where you can train a simple n-gram model to predict the next word based on your input.

## Features

- Train the model with custom sentences.
- Get real-time predictions for the next word as you type.

## How to Run

1. Install Python and Flask.
2. Run the backend server:
   ```bash
   python backend/app.py
   ```
3. Open the `frontend/index.html` file in your browser.
4. Start training and predicting!

## Future Improvements

- Add export/import functionality for the trained model.
- Upgrade to a more advanced ML model like RNN or Transformer.
- Deploy online for easy access.
